package com.example.myunisocieties

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.example.myunisocieties.ui.screens.Login

class MainActivity : ComponentActivity() {
    private lateinit var auth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Initialize Firebase
        auth = Firebase.auth
        auth.signOut() //forces a logout on rebuild
        setContent {
            MyApp() // Calls the root composable function
        }
    }
}


@Composable
fun MyApp() {
    var isUserLoggedIn by remember { mutableStateOf(Firebase.auth.currentUser != null) }
    if (isUserLoggedIn) {
        WelcomeScreen()
    } else {
        Login(onLoginSuccess = {
            isUserLoggedIn = true
        })
    }
}

@Composable
fun WelcomeScreen() {
    TODO("Not yet implemented")
}

