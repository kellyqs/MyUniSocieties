package com.example.myunisocieties.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.inventory.data.Society
import com.example.myunisocieties.data.model.SocietyDetails
import com.example.myunisocieties.ui.theme.MyUniSocietiesTheme

@Composable
fun SocietyEntryScreen(navController: NavHostController) {
    val societyDetails = remember { mutableStateOf(SocietyDetails()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Society Entry",
            style = MaterialTheme.typography.headlineMedium
        )

        SocietyInputForm(
            societyDetails = societyDetails.value,
            onValueChange = { updatedDetails -> societyDetails.value = updatedDetails },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                // Save the society details or perform navigation
                navController.navigate("signup")
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Save Society")
        }
    }
}
