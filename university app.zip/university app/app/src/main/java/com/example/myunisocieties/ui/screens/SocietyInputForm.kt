package com.example.myunisocieties.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.myunisocieties.data.model.SocietyDetails

@Composable
fun SocietyInputForm(
    societyDetails: SocietyDetails,
    onValueChange: (SocietyDetails) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Name Field
        OutlinedTextField(
            value = societyDetails.name,
            onValueChange = { onValueChange(societyDetails.copy(name = it)) },
            label = { Text("Society Name") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        // Description Field
        OutlinedTextField(
            value = societyDetails.description,
            onValueChange = { onValueChange(societyDetails.copy(description = it)) },
            label = { Text("Description") },
            modifier = Modifier.fillMaxWidth(),
            maxLines = 3
        )

        // Contact Email Field
        OutlinedTextField(
            value = societyDetails.contactEmail,
            onValueChange = { onValueChange(societyDetails.copy(contactEmail = it)) },
            label = { Text("Contact Email") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        // Category Field
        OutlinedTextField(
            value = societyDetails.category,
            onValueChange = { onValueChange(societyDetails.copy(category = it)) },
            label = { Text("Category (e.g., Engineering, Film, Anime)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        // Active Status Toggle
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Active Society")
            Switch(
                checked = societyDetails.isActive,
                onCheckedChange = { onValueChange(societyDetails.copy(isActive = it)) }
            )
        }
    }
}
