package com.example.myunisocieties.ui.Navigation


import SignUp
import androidx.compose.runtime.Composable
import androidx.compose.foundation.layout.PaddingValues
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.myunisocieties.ui.screens.AnimeSociety
import com.example.myunisocieties.ui.screens.EngineeringSociety
import com.example.myunisocieties.ui.screens.FilmSociety
import com.example.myunisocieties.ui.screens.HomeScreen
import com.example.myunisocieties.ui.screens.InternationalSociety
import com.example.myunisocieties.ui.screens.Login
import com.example.myunisocieties.ui.screens.SettingsScreen
import com.example.myunisocieties.ui.screens.SocietiesList
import com.example.myunisocieties.ui.screens.SocietyEntryScreen


@Composable
fun NavigationGraph(navController: NavHostController, paddingValues: PaddingValues) {
    NavHost(navController, startDestination = "home") {
        composable("home") { HomeScreen(navController) }
        composable("societyList") { SocietiesList(navController) }
        composable("filmSoc") { FilmSociety(navController) }
        composable("animeSoc") { AnimeSociety(navController) }
        composable("engineeringSoc") { EngineeringSociety(navController) }
        composable("internationalSoc") { InternationalSociety(navController) }
        composable("login") { Login(navController) }
        composable("signUp") { SignUp(navController) }
        composable("society_entry") { SocietyEntryScreen(navController) }
        composable("settings") { SettingsScreen(navController) }
    }
}


