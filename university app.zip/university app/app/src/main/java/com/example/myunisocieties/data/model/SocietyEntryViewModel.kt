package com.example.myunisocieties.data.model

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

// Data class representing the UI state of the society entry screen
data class SocietyUiState(
    val societyDetails: SocietyDetails = SocietyDetails(),
    val isEntryValid: Boolean = false
)

// Data class representing the details of a society
data class SocietyDetails(
    val name: String = "",
    val description: String = "",
    val contactEmail: String = "",
    val category: String = "",
    val isActive: Boolean = false
)

class SocietyEntryViewModel : ViewModel() {

    private val _societyUiState = MutableStateFlow(SocietyUiState())
    val societyUiState: StateFlow<SocietyUiState> = _societyUiState.asStateFlow()

    /**
     * Updates the UI state with new society details.
     */
    fun updateUiState(newDetails: SocietyDetails) {
        _societyUiState.value = _societyUiState.value.copy(
            societyDetails = newDetails,
            isEntryValid = validateInput(newDetails)
        )
    }

    /**
     * Validates the input fields.
     */
    private fun validateInput(details: SocietyDetails): Boolean {
        return details.name.isNotBlank() &&
                details.description.isNotBlank() &&
                details.contactEmail.isNotBlank() &&
                details.category.isNotBlank()
    }

    /**
     * Saves the society details to the database.
     */
    fun saveSociety() {
        viewModelScope.launch {
            // Replace this placeholder with your database saving logic.
            val society = _societyUiState.value.societyDetails
            saveToDatabase(society)
        }
    }

    /**
     * Placeholder method for saving to database.
     */
    private suspend fun saveToDatabase(society: SocietyDetails) {
        // Implement your database save operation here.
        // Example:
        // societyRepository.insertSociety(society)
        println("Saved society: $society")
    }
}
